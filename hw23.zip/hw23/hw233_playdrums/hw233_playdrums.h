// Add boilerplate here

// DO NOT MODIFY BELOW

#ifndef HW233_PLAYDRUMS_H_
#define HW233_PLAYDRUMS_H_

#ifndef HW222_CMIDIPACKET_H_
#include "hw222_CMidiPacket.h"
#endif

void create_gmdrums_vector(int start_note, int end_note);
void print_drums();

#endif // HW233_PLAYDRUMS_H_