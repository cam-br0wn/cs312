// Add boilerplate here

// DO NOT MODIFY BELOW

#ifndef HW234_SCIFISOUNDS_H_
#define HW234_SCIFISOUNDS_H_

#ifndef HW222_CMIDIPACKET_H_
#include "hw222_CMidiPacket.h"
#endif

void create_scifisounds_vector(int start_note, int end_note);
void print_scifi();

#endif // HW234_SCIFISOUNDS_H_